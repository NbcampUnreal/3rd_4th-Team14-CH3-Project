#include "GtGameplayTags.h"

namespace GtGameplayTags
{
	/* Weapons */
	UE_DEFINE_GAMEPLAY_TAG(Item_Weapon_HandGun, "Item.Weapon.HandGun");
	UE_DEFINE_GAMEPLAY_TAG(Item_Weapon_Riffle, "Item.Weapon.Riffle");
	UE_DEFINE_GAMEPLAY_TAG(Item_Weapon_Sniper, "Item.Weapon.Sniper");

	/* Grenade */
	UE_DEFINE_GAMEPLAY_TAG(Item_Grenade_Normal, "Item.Grenade.Normal");
	UE_DEFINE_GAMEPLAY_TAG(Item_Grenade_Flash, "Item.Grenade.Flash");
	UE_DEFINE_GAMEPLAY_TAG(Item_Grenade_Gravity, "Item.Grenade.Gravity");

	/* Consumable */
	UE_DEFINE_GAMEPLAY_TAG(Item_Consumable_Potion, "Item.Consumable.Potion");
	UE_DEFINE_GAMEPLAY_TAG(Item_Consumable_HealKit, "Item.Consumable.HealKit");
	UE_DEFINE_GAMEPLAY_TAG(Item_Consumable_HealPack, "Item.Consumable.HealPack");
}
